/******************************************************
** Program: 2Assignment.cpp
** Author: Stryder Garrett
** Date: 10/30/2022
** Description: Take in pre-exsisting pokedex and do requested actions with it
** Input: File Name, Different Options
** Output: Print or Save Choices to File 
******************************************************/
#include <iostream>
#include <fstream>
#include "HAssignment.h"
using namespace std;

int main()
{
    main_1();
    return 0;
}